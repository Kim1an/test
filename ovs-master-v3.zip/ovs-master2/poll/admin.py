from django.contrib import admin
from .models import Candidate, Position

@admin.register(Position)
class PositionAdmin(admin.ModelAdmin):
    list_display = ('title',)
    search_fields = ('title',)


@admin.register(Candidate)
class CandidateAdmin(admin.ModelAdmin):
    list_display = ('name','position','partylist')
    list_filter = ('position','partylist')
    search_fields = ('name','position','partylist')
    readonly_fields = ('total_vote',)
